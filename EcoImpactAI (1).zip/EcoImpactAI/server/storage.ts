import { type User, type InsertUser, type Product, type InsertProduct, type ImpactCalculation, type InsertImpactCalculation, type UserPreferences, type InsertUserPreferences, type DashboardMetrics } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Product operations
  getProduct(id: string): Promise<Product | undefined>;
  getProducts(): Promise<Product[]>;
  getProductsByCategory(category: string): Promise<Product[]>;
  searchProducts(query: string): Promise<Product[]>;
  getProductsBySustainabilityScore(minScore: number): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Impact calculation operations
  createImpactCalculation(calculation: InsertImpactCalculation): Promise<ImpactCalculation>;
  getImpactCalculations(userId?: string): Promise<ImpactCalculation[]>;
  
  // User preferences operations
  getUserPreferences(userId: string): Promise<UserPreferences | undefined>;
  createUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences>;
  updateUserPreferences(userId: string, preferences: Partial<InsertUserPreferences>): Promise<UserPreferences>;
  
  // Dashboard operations
  getDashboardMetrics(userId?: string): Promise<DashboardMetrics>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private products: Map<string, Product>;
  private impactCalculations: Map<string, ImpactCalculation>;
  private userPreferences: Map<string, UserPreferences>;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.impactCalculations = new Map();
    this.userPreferences = new Map();
    this.seedData();
  }

  private seedData() {
    // Seed some eco-friendly products
    const sampleProducts: InsertProduct[] = [
      {
        name: "Bamboo Phone Case",
        description: "100% biodegradable bamboo case with premium protection for your smartphone",
        category: "Electronics",
        price: "24.99",
        imageUrl: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        sustainabilityScore: "8.5",
        carbonFootprint: "Low",
        carbonFootprintValue: "2.1",
        waterUsage: "45",
        recyclability: 100,
        durability: "5 years",
        materials: ["bamboo", "natural fibers"],
        certifications: ["FSC Certified", "Biodegradable"]
      },
      {
        name: "Organic Cotton T-Shirt",
        description: "GOTS certified organic cotton with fair trade sourcing and sustainable production",
        category: "Clothing",
        price: "32.99",
        imageUrl: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        sustainabilityScore: "9.2",
        carbonFootprint: "Very Low",
        carbonFootprintValue: "1.8",
        waterUsage: "85",
        recyclability: 90,
        durability: "3+ years",
        materials: ["organic cotton"],
        certifications: ["GOTS Certified", "Fair Trade", "Organic"]
      },
      {
        name: "Solar Garden Lights",
        description: "Energy-efficient LED lights powered entirely by renewable solar energy",
        category: "Home & Garden",
        price: "89.99",
        imageUrl: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        sustainabilityScore: "9.5",
        carbonFootprint: "Zero",
        carbonFootprintValue: "0",
        waterUsage: "12",
        recyclability: 85,
        durability: "10+ years",
        materials: ["recycled aluminum", "solar cells", "LED"],
        certifications: ["Energy Star", "Solar Certified"]
      },
      {
        name: "Reusable Water Bottle",
        description: "Stainless steel bottle with vacuum insulation, BPA-free and dishwasher safe",
        category: "Personal Care",
        price: "28.99",
        imageUrl: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        sustainabilityScore: "8.8",
        carbonFootprint: "Low",
        carbonFootprintValue: "3.2",
        waterUsage: "25",
        recyclability: 95,
        durability: "15+ years",
        materials: ["stainless steel", "silicone"],
        certifications: ["BPA-Free", "Food Grade"]
      },
      {
        name: "Hemp Backpack",
        description: "Durable hemp fabric backpack with recycled polyester lining and fair trade production",
        category: "Accessories",
        price: "67.99",
        imageUrl: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        sustainabilityScore: "8.7",
        carbonFootprint: "Medium",
        carbonFootprintValue: "5.4",
        waterUsage: "120",
        recyclability: 80,
        durability: "8+ years",
        materials: ["hemp", "recycled polyester"],
        certifications: ["Fair Trade", "Recycled Content"]
      },
      {
        name: "LED Smart Bulb",
        description: "Energy-efficient smart LED bulb with app control and 90% energy savings",
        category: "Electronics",
        price: "19.99",
        imageUrl: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        sustainabilityScore: "8.3",
        carbonFootprint: "Very Low",
        carbonFootprintValue: "1.2",
        waterUsage: "8",
        recyclability: 75,
        durability: "25+ years",
        materials: ["LED", "recycled aluminum", "smart chip"],
        certifications: ["Energy Star", "RoHS Compliant"]
      }
    ];

    sampleProducts.forEach(product => {
      this.createProduct(product);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product => 
      product.category.toLowerCase() === category.toLowerCase()
    );
  }

  async searchProducts(query: string): Promise<Product[]> {
    const searchTerm = query.toLowerCase();
    return Array.from(this.products.values()).filter(product =>
      product.name.toLowerCase().includes(searchTerm) ||
      product.description.toLowerCase().includes(searchTerm) ||
      product.category.toLowerCase().includes(searchTerm) ||
      product.materials.some(material => material.toLowerCase().includes(searchTerm))
    );
  }

  async getProductsBySustainabilityScore(minScore: number): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product =>
      parseFloat(product.sustainabilityScore) >= minScore
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { ...insertProduct, id, createdAt: new Date() };
    this.products.set(id, product);
    return product;
  }

  async createImpactCalculation(insertCalculation: InsertImpactCalculation): Promise<ImpactCalculation> {
    const id = randomUUID();
    const calculation: ImpactCalculation = { ...insertCalculation, id, createdAt: new Date() };
    this.impactCalculations.set(id, calculation);
    return calculation;
  }

  async getImpactCalculations(userId?: string): Promise<ImpactCalculation[]> {
    const calculations = Array.from(this.impactCalculations.values());
    if (userId) {
      return calculations.filter(calc => calc.userId === userId);
    }
    return calculations;
  }

  async getUserPreferences(userId: string): Promise<UserPreferences | undefined> {
    return Array.from(this.userPreferences.values()).find(pref => pref.userId === userId);
  }

  async createUserPreferences(insertPreferences: InsertUserPreferences): Promise<UserPreferences> {
    const id = randomUUID();
    const preferences: UserPreferences = { ...insertPreferences, id, createdAt: new Date() };
    this.userPreferences.set(id, preferences);
    return preferences;
  }

  async updateUserPreferences(userId: string, updateData: Partial<InsertUserPreferences>): Promise<UserPreferences> {
    const existing = await this.getUserPreferences(userId);
    if (!existing) {
      throw new Error("User preferences not found");
    }
    const updated: UserPreferences = { ...existing, ...updateData };
    this.userPreferences.set(existing.id, updated);
    return updated;
  }

  async getDashboardMetrics(userId?: string): Promise<DashboardMetrics> {
    const calculations = await this.getImpactCalculations(userId);
    
    // Calculate average metrics
    const avgCarbonFootprint = calculations.length > 0 
      ? calculations.reduce((sum, calc) => sum + parseFloat(calc.carbonFootprint.toString()), 0) / calculations.length 
      : 2.4;
    
    const avgWaterUsage = calculations.length > 0
      ? calculations.reduce((sum, calc) => sum + parseFloat(calc.waterUsage.toString()), 0) / calculations.length
      : 1250;
    
    const avgRecyclability = calculations.length > 0
      ? calculations.reduce((sum, calc) => sum + calc.recyclability, 0) / calculations.length
      : 85;
    
    const avgSustainabilityScore = calculations.length > 0
      ? calculations.reduce((sum, calc) => sum + parseFloat(calc.sustainabilityScore.toString()), 0) / calculations.length
      : 8.2;

    // Generate monthly impact data
    const monthlyImpact = [
      { month: "Jan", score: 6.8, carbonSaved: 12.5 },
      { month: "Feb", score: 7.2, carbonSaved: 18.3 },
      { month: "Mar", score: 7.8, carbonSaved: 24.1 },
      { month: "Apr", score: 8.1, carbonSaved: 28.7 },
      { month: "May", score: 8.3, carbonSaved: 32.4 },
      { month: "Jun", score: avgSustainabilityScore, carbonSaved: 35.8 }
    ];

    return {
      carbonFootprint: avgCarbonFootprint,
      waterUsage: avgWaterUsage,
      recyclability: avgRecyclability,
      sustainabilityScore: avgSustainabilityScore,
      monthlyImpact
    };
  }
}

export const storage = new MemStorage();
