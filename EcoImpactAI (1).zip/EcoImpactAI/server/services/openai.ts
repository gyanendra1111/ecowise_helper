import OpenAI from "openai";
import { Product, ImpactCalculation, AIRecommendation } from "@shared/schema";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export async function calculateProductImpact(productName: string, category: string): Promise<{
  sustainabilityScore: number;
  carbonFootprint: number;
  waterUsage: number;
  recyclability: number;
  recommendations: string[];
}> {
  try {
    const prompt = `Analyze the environmental impact of "${productName}" in the "${category}" category. 
    Provide a detailed sustainability assessment including:
    - Sustainability score (0-10)
    - Carbon footprint in kg CO2
    - Water usage in liters
    - Recyclability percentage (0-100)
    - 3 specific recommendations for improvement
    
    Respond with JSON in this exact format:
    {
      "sustainabilityScore": number,
      "carbonFootprint": number,
      "waterUsage": number,
      "recyclability": number,
      "recommendations": [string, string, string]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are an environmental impact assessment expert. Provide accurate, data-driven sustainability analysis."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      sustainabilityScore: Math.max(0, Math.min(10, result.sustainabilityScore || 5)),
      carbonFootprint: Math.max(0, result.carbonFootprint || 5),
      waterUsage: Math.max(0, result.waterUsage || 100),
      recyclability: Math.max(0, Math.min(100, result.recyclability || 50)),
      recommendations: Array.isArray(result.recommendations) ? result.recommendations.slice(0, 3) : []
    };
  } catch (error) {
    console.error("Error calculating product impact:", error);
    throw new Error("Failed to calculate environmental impact: " + (error as Error).message);
  }
}

export async function generateProductRecommendations(
  userPreferences: { categories: string[], maxPrice?: number, minSustainabilityScore?: number },
  products: Product[]
): Promise<AIRecommendation[]> {
  try {
    const prompt = `Based on user preferences and available products, recommend the most suitable eco-friendly products.
    
    User Preferences:
    - Preferred categories: ${userPreferences.categories.join(", ")}
    - Max price: ${userPreferences.maxPrice || "no limit"}
    - Min sustainability score: ${userPreferences.minSustainabilityScore || "any"}
    
    Available Products: ${JSON.stringify(products.slice(0, 10))}
    
    Provide 3-5 personalized recommendations with reasons. Respond with JSON in this format:
    {
      "recommendations": [
        {
          "productId": "string",
          "reason": "string explaining why this product is recommended",
          "confidenceScore": number (0-1),
          "impactImprovement": number (percentage improvement in sustainability)
        }
      ]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are an AI sustainability advisor. Provide personalized, environmentally-focused product recommendations."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return (result.recommendations || []).map((rec: any, index: number) => ({
      id: `ai_rec_${Date.now()}_${index}`,
      productId: rec.productId,
      reason: rec.reason || "Recommended based on your preferences",
      confidenceScore: Math.max(0, Math.min(1, rec.confidenceScore || 0.7)),
      impactImprovement: Math.max(0, Math.min(100, rec.impactImprovement || 15))
    }));
  } catch (error) {
    console.error("Error generating recommendations:", error);
    throw new Error("Failed to generate AI recommendations: " + (error as Error).message);
  }
}

export async function generateSustainabilityInsights(metrics: {
  carbonFootprint: number;
  waterUsage: number;
  recyclability: number;
  sustainabilityScore: number;
}): Promise<string> {
  try {
    const prompt = `Analyze these environmental metrics and provide personalized sustainability insights:
    - Carbon footprint: ${metrics.carbonFootprint} kg CO2
    - Water usage: ${metrics.waterUsage} liters
    - Recyclability: ${metrics.recyclability}%
    - Overall sustainability score: ${metrics.sustainabilityScore}/10
    
    Provide a brief, actionable insight (2-3 sentences) about their environmental impact and specific recommendations for improvement.`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a sustainability coach. Provide encouraging, specific, and actionable environmental advice."
        },
        {
          role: "user",
          content: prompt
        }
      ]
    });

    return response.choices[0].message.content || "Keep making sustainable choices to reduce your environmental impact!";
  } catch (error) {
    console.error("Error generating insights:", error);
    return "Continue focusing on sustainable products to improve your environmental impact.";
  }
}

export async function compareSustainabilityAlternatives(
  productName: string,
  category: string
): Promise<string[]> {
  try {
    const prompt = `Suggest 3-5 sustainable alternatives to "${productName}" in the "${category}" category.
    Focus on products with better environmental impact, recyclability, or carbon footprint.
    
    Respond with JSON in this format:
    {
      "alternatives": ["product name 1", "product name 2", "product name 3"]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are an expert in sustainable products and eco-friendly alternatives."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.alternatives || [];
  } catch (error) {
    console.error("Error finding alternatives:", error);
    return [];
  }
}
