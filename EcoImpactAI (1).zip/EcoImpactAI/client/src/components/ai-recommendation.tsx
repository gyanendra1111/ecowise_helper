import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bot } from "lucide-react";

interface AIRecommendationProps {
  insight: string;
  onGetRecommendations?: () => void;
}

export default function AIRecommendation({ insight, onGetRecommendations }: AIRecommendationProps) {
  return (
    <Card className="bg-gradient-to-r from-primary/5 to-accent/5 border-primary/20" data-testid="card-ai-recommendation">
      <CardContent className="p-8">
        <div className="flex items-start space-x-4">
          <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
            <Bot className="text-primary h-6 w-6" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-semibold text-foreground mb-2">AI Recommendation</h3>
            <p className="text-muted-foreground mb-4" data-testid="text-ai-insight">
              {insight}
            </p>
            <Button 
              onClick={onGetRecommendations}
              data-testid="button-get-recommendations"
            >
              Get Personalized Recommendations
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
