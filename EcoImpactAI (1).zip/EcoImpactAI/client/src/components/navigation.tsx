import { Link, useLocation } from "wouter";
import { Search, Leaf } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navigation() {
  const [location] = useLocation();

  const isActive = (path: string) => location === path;

  return (
    <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center space-x-2" data-testid="link-home">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Leaf className="text-primary-foreground h-4 w-4" />
            </div>
            <span className="text-xl font-bold text-foreground">EcoWise</span>
          </Link>
          
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              href="/dashboard" 
              className={`transition-colors ${isActive('/dashboard') ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              data-testid="link-dashboard"
            >
              Impact Calculator
            </Link>
            <Link 
              href="/products" 
              className={`transition-colors ${isActive('/products') ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              data-testid="link-products"
            >
              Products
            </Link>
            <Link 
              href="/dashboard" 
              className={`transition-colors ${isActive('/dashboard') ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              data-testid="link-dashboard-nav"
            >
              Dashboard
            </Link>
            <Link 
              href="/compare" 
              className={`transition-colors ${isActive('/compare') ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              data-testid="link-compare"
            >
              Compare
            </Link>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" data-testid="button-search">
              <Search className="h-4 w-4" />
            </Button>
            <Button data-testid="button-get-started">
              Get Started
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
