import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Cloud, Droplets, Recycle, Leaf } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

interface DashboardMetricsProps {
  metrics: {
    carbonFootprint: number;
    waterUsage: number;
    recyclability: number;
    sustainabilityScore: number;
    monthlyImpact: Array<{
      month: string;
      score: number;
      carbonSaved: number;
    }>;
  };
}

export default function DashboardMetrics({ metrics }: DashboardMetricsProps) {
  const metricCards = [
    {
      title: "Carbon Footprint",
      value: `${metrics.carbonFootprint.toFixed(1)} tons`,
      subtitle: "33% reduction this year",
      icon: Cloud,
      progress: 33,
      color: "text-chart-1",
      testId: "carbon-footprint"
    },
    {
      title: "Water Usage",
      value: `${metrics.waterUsage.toFixed(0)} L`,
      subtitle: "18% reduction this month",
      icon: Droplets,
      progress: 50,
      color: "text-chart-2",
      testId: "water-usage"
    },
    {
      title: "Recyclability",
      value: `${metrics.recyclability.toFixed(0)}%`,
      subtitle: "Above average",
      icon: Recycle,
      progress: 67,
      color: "text-chart-3",
      testId: "recyclability"
    },
    {
      title: "Overall Score",
      value: `${metrics.sustainabilityScore.toFixed(1)}/10`,
      subtitle: "Excellent rating",
      icon: Leaf,
      progress: 78,
      color: "text-primary",
      testId: "sustainability-score"
    }
  ];

  return (
    <div className="space-y-8">
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {metricCards.map((card) => (
          <Card key={card.title} className="text-center" data-testid={`card-${card.testId}`}>
            <CardContent className="p-6">
              <div className="w-20 h-20 mx-auto mb-4 relative">
                <div 
                  className="impact-ring w-full h-full" 
                  style={{"--progress": `${(card.progress / 100) * 360}deg`} as React.CSSProperties}
                ></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <card.icon className={`${card.color} h-6 w-6`} />
                </div>
              </div>
              <h3 className="font-semibold text-foreground mb-2">{card.title}</h3>
              <div className={`text-2xl font-bold ${card.color} mb-1`} data-testid={`text-${card.testId}`}>
                {card.value}
              </div>
              <div className="text-sm text-muted-foreground">{card.subtitle}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card data-testid="card-impact-timeline">
        <CardHeader>
          <CardTitle>Your Impact Over Time</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={metrics.monthlyImpact}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="score" fill="var(--chart-1)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-between items-center mt-6">
            <div className="text-sm text-muted-foreground">Sustainability Score Improvement</div>
            <div className="text-sm font-semibold text-primary">+2.3 points this quarter</div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
