import { Product } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowDown, ArrowUp } from "lucide-react";

interface ComparisonTableProps {
  products: Product[];
  onAddProduct?: () => void;
  onShareComparison?: () => void;
}

export default function ComparisonTable({ products, onAddProduct, onShareComparison }: ComparisonTableProps) {
  if (products.length === 0) {
    return (
      <Card data-testid="card-comparison-empty">
        <CardContent className="p-8 text-center">
          <p className="text-muted-foreground mb-4">No products selected for comparison</p>
          <Button onClick={onAddProduct} data-testid="button-add-first-product">
            Add Products to Compare
          </Button>
        </CardContent>
      </Card>
    );
  }

  const getCarbonFootprintBadge = (footprint: string, value: string) => {
    const isLow = footprint.toLowerCase().includes("low") || footprint.toLowerCase() === "zero";
    return (
      <Badge variant={isLow ? "default" : "destructive"} className="flex items-center gap-1">
        {isLow ? <ArrowDown className="h-3 w-3" /> : <ArrowUp className="h-3 w-3" />}
        {footprint} ({value} kg CO₂)
      </Badge>
    );
  };

  const getBestProduct = () => {
    return products.reduce((best, current) => {
      const bestScore = parseFloat(best.sustainabilityScore);
      const currentScore = parseFloat(current.sustainabilityScore);
      return currentScore > bestScore ? current : best;
    });
  };

  const bestProduct = getBestProduct();

  return (
    <Card data-testid="card-comparison-table">
      <CardHeader>
        <CardTitle>Product Comparison</CardTitle>
        <p className="text-muted-foreground">Compare environmental impact and sustainability metrics side-by-side</p>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full" data-testid="table-comparison">
            <thead className="bg-muted/50">
              <tr>
                <th className="text-left p-4 font-medium text-foreground">Metrics</th>
                {products.map((product) => (
                  <th key={product.id} className="text-center p-4" data-testid={`column-${product.id}`}>
                    <div className="space-y-2">
                      <img 
                        src={product.imageUrl} 
                        alt={product.name} 
                        className="w-16 h-12 object-cover rounded mx-auto"
                        data-testid={`img-comparison-${product.id}`}
                      />
                      <div className="text-sm font-medium text-foreground" data-testid={`text-comparison-name-${product.id}`}>
                        {product.name}
                      </div>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-border">
                <td className="p-4 font-medium text-foreground">Sustainability Score</td>
                {products.map((product) => {
                  const score = parseFloat(product.sustainabilityScore);
                  const progressPercentage = (score / 10) * 100;
                  return (
                    <td key={product.id} className="p-4 text-center">
                      <div className="flex items-center justify-center space-x-2">
                        <div 
                          className="w-16 h-2 bg-muted rounded-full progress-bar" 
                          style={{"--progress": `${progressPercentage}%`} as React.CSSProperties}
                        ></div>
                        <span 
                          className={`font-bold ${product.id === bestProduct.id ? 'text-primary' : 'text-muted-foreground'}`}
                          data-testid={`text-comparison-score-${product.id}`}
                        >
                          {score.toFixed(1)}/10
                        </span>
                      </div>
                    </td>
                  );
                })}
              </tr>
              
              <tr className="border-b border-border">
                <td className="p-4 font-medium text-foreground">Carbon Footprint</td>
                {products.map((product) => (
                  <td key={product.id} className="p-4 text-center" data-testid={`text-comparison-carbon-${product.id}`}>
                    {getCarbonFootprintBadge(product.carbonFootprint, product.carbonFootprintValue || "0")}
                  </td>
                ))}
              </tr>
              
              <tr className="border-b border-border">
                <td className="p-4 font-medium text-foreground">Water Usage</td>
                {products.map((product) => (
                  <td key={product.id} className="p-4 text-center">
                    <span className="font-semibold text-chart-2" data-testid={`text-comparison-water-${product.id}`}>
                      {product.waterUsage} L
                    </span>
                  </td>
                ))}
              </tr>
              
              <tr className="border-b border-border">
                <td className="p-4 font-medium text-foreground">Recyclability</td>
                {products.map((product) => (
                  <td key={product.id} className="p-4 text-center">
                    <span className="font-semibold text-chart-1" data-testid={`text-comparison-recyclability-${product.id}`}>
                      {product.recyclability}%
                    </span>
                  </td>
                ))}
              </tr>
              
              <tr className="border-b border-border">
                <td className="p-4 font-medium text-foreground">Durability</td>
                {products.map((product) => (
                  <td key={product.id} className="p-4 text-center">
                    <span className="font-semibold text-chart-3" data-testid={`text-comparison-durability-${product.id}`}>
                      {product.durability}
                    </span>
                  </td>
                ))}
              </tr>
              
              <tr>
                <td className="p-4 font-medium text-foreground">Price</td>
                {products.map((product) => (
                  <td key={product.id} className="p-4 text-center">
                    <span className="text-xl font-bold text-foreground" data-testid={`text-comparison-price-${product.id}`}>
                      ${product.price}
                    </span>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
        
        <div className="p-6 bg-accent/10 border-t border-border">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-semibold text-foreground mb-1">Recommendation</h4>
              <p className="text-muted-foreground text-sm" data-testid="text-comparison-recommendation">
                {bestProduct.name} offers the best sustainability score with excellent environmental benefits.
              </p>
            </div>
            <div className="flex space-x-4">
              <Button variant="secondary" onClick={onAddProduct} data-testid="button-add-another-product">
                Add Another Product
              </Button>
              <Button onClick={onShareComparison} data-testid="button-share-comparison">
                Share Comparison
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
