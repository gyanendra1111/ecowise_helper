import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import ProductCard from "@/components/product-card";
import AIRecommendation from "@/components/ai-recommendation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Product } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function Products() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [minSustainabilityScore, setMinSustainabilityScore] = useState("");
  const { toast } = useToast();

  const { data: products = [], isLoading } = useQuery({
    queryKey: ["/api/products", { 
      search: searchQuery || undefined, 
      category: selectedCategory || undefined,
      minScore: minSustainabilityScore || undefined 
    }],
    staleTime: 300000,
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["/api/categories"],
    staleTime: 600000, // 10 minutes
  });

  const recommendationsMutation = useMutation({
    mutationFn: async (preferences: { categories: string[], maxPrice?: number, minSustainabilityScore?: number }) => {
      const response = await apiRequest("POST", "/api/recommendations", preferences);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Recommendations Generated",
        description: `Found ${data.length} personalized recommendations for you.`
      });
    },
    onError: (error) => {
      toast({
        title: "Recommendation Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const handleApplyFilters = () => {
    // Filters are applied automatically through query keys
    toast({
      title: "Filters Applied",
      description: "Product list updated with your sustainability criteria."
    });
  };

  const handleGetRecommendations = () => {
    const preferences = {
      categories: selectedCategory ? [selectedCategory] : [],
      minSustainabilityScore: minSustainabilityScore ? parseFloat(minSustainabilityScore) : undefined
    };
    recommendationsMutation.mutate(preferences);
  };

  const handleViewProductDetails = (product: Product) => {
    toast({
      title: `${product.name}`,
      description: `Sustainability Score: ${product.sustainabilityScore}/10`
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-foreground mb-4">AI-Powered Product Recommendations</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover sustainable alternatives tailored to your preferences and environmental goals
          </p>
        </div>
        
        {/* Search and Filter Bar */}
        <div className="bg-card border border-border rounded-xl p-6 mb-12" data-testid="card-search-filters">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Search eco-friendly products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-products"
                />
              </div>
            </div>
            
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-48" data-testid="select-category-filter">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Categories</SelectItem>
                {categories.map((category: string) => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={minSustainabilityScore} onValueChange={setMinSustainabilityScore}>
              <SelectTrigger className="w-48" data-testid="select-sustainability-filter">
                <SelectValue placeholder="Sustainability Score" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">Any Score</SelectItem>
                <SelectItem value="9">9+ Excellent</SelectItem>
                <SelectItem value="7">7-8 Good</SelectItem>
                <SelectItem value="5">5-6 Fair</SelectItem>
              </SelectContent>
            </Select>
            
            <Button onClick={handleApplyFilters} data-testid="button-apply-filters">
              Apply Filters
            </Button>
          </div>
        </div>
        
        {/* Products Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-card border border-border rounded-xl h-96 animate-pulse" />
            ))}
          </div>
        ) : products.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12" data-testid="grid-products">
            {products.map((product: Product) => (
              <ProductCard 
                key={product.id} 
                product={product} 
                onViewDetails={handleViewProductDetails}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12" data-testid="empty-products">
            <p className="text-muted-foreground text-lg mb-4">No products found matching your criteria</p>
            <Button variant="outline" onClick={() => {
              setSearchQuery("");
              setSelectedCategory("");
              setMinSustainabilityScore("");
            }}>
              Clear Filters
            </Button>
          </div>
        )}
        
        {/* AI Recommendation */}
        <AIRecommendation 
          insight="Based on your search preferences and sustainability criteria, I recommend focusing on renewable energy products and organic materials. These categories show the highest environmental impact improvements for users with similar preferences."
          onGetRecommendations={handleGetRecommendations}
        />
      </div>
    </div>
  );
}
