import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import ComparisonTable from "@/components/comparison-table";
import ProductCard from "@/components/product-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, Plus, X } from "lucide-react";
import { Product } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Compare() {
  const [selectedProducts, setSelectedProducts] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [showProductSelector, setShowProductSelector] = useState(false);
  const { toast } = useToast();

  const { data: allProducts = [] } = useQuery({
    queryKey: ["/api/products", { search: searchQuery || undefined }],
    staleTime: 300000,
  });

  const compareMutation = useMutation({
    mutationFn: async (productIds: string[]) => {
      const response = await apiRequest("POST", "/api/compare", { productIds });
      return response.json();
    },
    onSuccess: (data) => {
      setSelectedProducts(data);
      toast({
        title: "Products Compared",
        description: `Successfully loaded comparison data for ${data.length} products.`
      });
    },
    onError: (error) => {
      toast({
        title: "Comparison Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const availableProducts = allProducts.filter(
    (product: Product) => !selectedProducts.some(selected => selected.id === product.id)
  );

  const handleAddProduct = (product: Product) => {
    if (selectedProducts.length >= 4) {
      toast({
        title: "Maximum Products",
        description: "You can compare up to 4 products at a time.",
        variant: "destructive"
      });
      return;
    }
    
    setSelectedProducts(prev => [...prev, product]);
    setShowProductSelector(false);
    toast({
      title: "Product Added",
      description: `${product.name} added to comparison.`
    });
  };

  const handleRemoveProduct = (productId: string) => {
    setSelectedProducts(prev => prev.filter(p => p.id !== productId));
    toast({
      title: "Product Removed",
      description: "Product removed from comparison."
    });
  };

  const handleShareComparison = () => {
    if (selectedProducts.length === 0) {
      toast({
        title: "No Products to Share",
        description: "Add products to the comparison first.",
        variant: "destructive"
      });
      return;
    }

    // Copy comparison URL to clipboard
    const url = `${window.location.origin}/compare?products=${selectedProducts.map(p => p.id).join(',')}`;
    navigator.clipboard.writeText(url).then(() => {
      toast({
        title: "Comparison Shared",
        description: "Comparison link copied to clipboard!"
      });
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4">Product Comparison Tool</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Compare environmental impact and sustainability metrics side-by-side
          </p>
        </div>

        {/* Selected Products for Comparison */}
        {selectedProducts.length > 0 && (
          <Card className="mb-8" data-testid="card-selected-products">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Selected Products ({selectedProducts.length}/4)</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedProducts([])}
                  data-testid="button-clear-selection"
                >
                  Clear All
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4">
                {selectedProducts.map((product) => (
                  <div key={product.id} className="relative" data-testid={`selected-product-${product.id}`}>
                    <div className="w-32 h-32 bg-card border border-border rounded-lg overflow-hidden">
                      <img 
                        src={product.imageUrl} 
                        alt={product.name} 
                        className="w-full h-20 object-cover"
                      />
                      <div className="p-2">
                        <p className="text-xs font-medium truncate" title={product.name}>
                          {product.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          ${product.price}
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute -top-2 -right-2 h-6 w-6"
                      onClick={() => handleRemoveProduct(product.id)}
                      data-testid={`button-remove-${product.id}`}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Product Selector */}
        <Card className="mb-8" data-testid="card-product-selector">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Add Products to Compare</span>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Search products..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 w-64"
                    data-testid="input-search-compare"
                  />
                </div>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {availableProducts.slice(0, 6).map((product: Product) => (
                <div key={product.id} className="relative">
                  <ProductCard product={product} />
                  <Button
                    className="absolute top-4 right-4"
                    size="sm"
                    onClick={() => handleAddProduct(product)}
                    data-testid={`button-add-to-compare-${product.id}`}
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Comparison Table */}
        <ComparisonTable 
          products={selectedProducts}
          onAddProduct={() => setShowProductSelector(true)}
          onShareComparison={handleShareComparison}
        />
      </div>
    </div>
  );
}
