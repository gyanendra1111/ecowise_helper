import { sql } from "drizzle-orm";
import { pgTable, text, varchar, numeric, integer, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const products = pgTable("products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  imageUrl: text("image_url").notNull(),
  sustainabilityScore: numeric("sustainability_score", { precision: 3, scale: 1 }).notNull(),
  carbonFootprint: text("carbon_footprint").notNull(), // "Low", "Medium", "High", "Zero"
  carbonFootprintValue: numeric("carbon_footprint_value", { precision: 8, scale: 2 }), // kg CO2
  waterUsage: numeric("water_usage", { precision: 8, scale: 2 }), // liters
  recyclability: integer("recyclability").notNull(), // percentage 0-100
  durability: text("durability").notNull(), // "2 years", "5+ years", etc.
  materials: jsonb("materials").notNull().$type<string[]>(),
  certifications: jsonb("certifications").notNull().$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const impactCalculations = pgTable("impact_calculations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  productName: text("product_name").notNull(),
  category: text("category").notNull(),
  sustainabilityScore: numeric("sustainability_score", { precision: 3, scale: 1 }).notNull(),
  carbonFootprint: numeric("carbon_footprint", { precision: 8, scale: 2 }).notNull(),
  waterUsage: numeric("water_usage", { precision: 8, scale: 2 }).notNull(),
  recyclability: integer("recyclability").notNull(),
  recommendations: jsonb("recommendations").notNull().$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userPreferences = pgTable("user_preferences", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  categories: jsonb("categories").notNull().$type<string[]>(),
  maxPrice: numeric("max_price", { precision: 10, scale: 2 }),
  minSustainabilityScore: numeric("min_sustainability_score", { precision: 3, scale: 1 }),
  priorityFactors: jsonb("priority_factors").notNull().$type<string[]>(), // ["carbon", "recyclability", "durability"]
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
});

export const insertImpactCalculationSchema = createInsertSchema(impactCalculations).omit({
  id: true,
  createdAt: true,
});

export const insertUserPreferencesSchema = createInsertSchema(userPreferences).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type ImpactCalculation = typeof impactCalculations.$inferSelect;
export type InsertImpactCalculation = z.infer<typeof insertImpactCalculationSchema>;
export type UserPreferences = typeof userPreferences.$inferSelect;
export type InsertUserPreferences = z.infer<typeof insertUserPreferencesSchema>;

// Additional types for API responses
export type ProductWithImpact = Product & {
  impactScore: number;
  alternativeProducts?: Product[];
};

export type DashboardMetrics = {
  carbonFootprint: number;
  waterUsage: number;
  recyclability: number;
  sustainabilityScore: number;
  monthlyImpact: Array<{
    month: string;
    score: number;
    carbonSaved: number;
  }>;
};

export type AIRecommendation = {
  id: string;
  productId: string;
  reason: string;
  confidenceScore: number;
  impactImprovement: number;
};
