import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Calculator, Loader2 } from "lucide-react";

interface ImpactResult {
  sustainabilityScore: number;
  carbonFootprint: number;
  waterUsage: number;
  recyclability: number;
  recommendations: string[];
}

export default function ImpactCalculator() {
  const [productName, setProductName] = useState("");
  const [category, setCategory] = useState("");
  const [result, setResult] = useState<ImpactResult | null>(null);
  const { toast } = useToast();

  const calculateMutation = useMutation({
    mutationFn: async (data: { productName: string; category: string }) => {
      const response = await apiRequest("POST", "/api/impact/calculate", data);
      return response.json();
    },
    onSuccess: (data) => {
      setResult(data);
      toast({
        title: "Impact Calculated",
        description: "Environmental impact analysis completed successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Calculation Failed",
        description: error.message || "Failed to calculate environmental impact",
        variant: "destructive"
      });
    }
  });

  const handleCalculate = () => {
    if (!productName || !category) {
      toast({
        title: "Missing Information",
        description: "Please enter both product name and category",
        variant: "destructive"
      });
      return;
    }
    calculateMutation.mutate({ productName, category });
  };

  return (
    <Card data-testid="card-impact-calculator">
      <CardHeader>
        <CardTitle className="text-2xl font-semibold text-center">Quick Impact Calculator</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <Label htmlFor="category" className="block text-sm font-medium text-foreground mb-2">
            Product Category
          </Label>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger data-testid="select-category">
              <SelectValue placeholder="Select a category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Electronics">Electronics</SelectItem>
              <SelectItem value="Clothing">Clothing</SelectItem>
              <SelectItem value="Home & Garden">Home & Garden</SelectItem>
              <SelectItem value="Personal Care">Personal Care</SelectItem>
              <SelectItem value="Accessories">Accessories</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="productName" className="block text-sm font-medium text-foreground mb-2">
            Product Name
          </Label>
          <Input
            id="productName"
            type="text"
            placeholder="Enter product name"
            value={productName}
            onChange={(e) => setProductName(e.target.value)}
            data-testid="input-product-name"
          />
        </div>
        
        <Button 
          onClick={handleCalculate}
          disabled={calculateMutation.isPending}
          className="w-full"
          data-testid="button-calculate-impact"
        >
          {calculateMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Calculator className="mr-2 h-4 w-4" />
              Analyze Impact
            </>
          )}
        </Button>
        
        {result && (
          <div className="mt-6 p-4 bg-secondary/20 rounded-lg border border-secondary/30" data-testid="result-impact">
            <div className="flex items-center justify-between mb-3">
              <span className="font-medium">Sustainability Score</span>
              <div className="flex items-center space-x-2">
                <div 
                  className="w-16 h-2 bg-muted rounded-full progress-bar" 
                  style={{"--progress": `${(result.sustainabilityScore / 10) * 100}%`} as React.CSSProperties}
                ></div>
                <span className="font-bold text-primary" data-testid="text-sustainability-score">
                  {result.sustainabilityScore.toFixed(1)}/10
                </span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Carbon Footprint:</span>
                <div className="font-semibold text-chart-1" data-testid="text-carbon-footprint">
                  {result.carbonFootprint.toFixed(1)} kg CO₂
                </div>
              </div>
              <div>
                <span className="text-muted-foreground">Water Usage:</span>
                <div className="font-semibold text-chart-2" data-testid="text-water-usage">
                  {result.waterUsage.toFixed(0)} L
                </div>
              </div>
              <div>
                <span className="text-muted-foreground">Recyclability:</span>
                <div className="font-semibold text-chart-3" data-testid="text-recyclability">
                  {result.recyclability}%
                </div>
              </div>
            </div>
            {result.recommendations.length > 0 && (
              <div className="mt-4">
                <h4 className="font-medium text-sm mb-2">Recommendations:</h4>
                <ul className="text-xs text-muted-foreground space-y-1" data-testid="list-recommendations">
                  {result.recommendations.map((rec, index) => (
                    <li key={index}>• {rec}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
