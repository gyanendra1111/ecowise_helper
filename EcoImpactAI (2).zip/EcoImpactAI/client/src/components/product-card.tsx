import { Product } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Leaf, Shirt, Home, User, Zap } from "lucide-react";

interface ProductCardProps {
  product: Product;
  onViewDetails?: (product: Product) => void;
}

const categoryIcons = {
  "Electronics": Zap,
  "Clothing": Shirt,
  "Home & Garden": Home,
  "Personal Care": User,
  "Accessories": Leaf
};

export default function ProductCard({ product, onViewDetails }: ProductCardProps) {
  const Icon = categoryIcons[product.category as keyof typeof categoryIcons] || Leaf;
  const sustainabilityScore = parseFloat(product.sustainabilityScore);
  const progressPercentage = (sustainabilityScore / 10) * 100;

  const getCarbonFootprintColor = (footprint: string) => {
    switch (footprint.toLowerCase()) {
      case "zero":
        return "text-chart-1";
      case "very low":
      case "low":
        return "text-chart-1";
      case "medium":
        return "text-chart-3";
      case "high":
        return "text-chart-4";
      default:
        return "text-chart-1";
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow" data-testid={`card-product-${product.id}`}>
      <img 
        src={product.imageUrl} 
        alt={product.name} 
        className="w-full h-48 object-cover"
        data-testid={`img-product-${product.id}`}
      />
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-2">
          <Badge variant="outline" className="flex items-center gap-1" data-testid={`badge-category-${product.id}`}>
            <Icon className="h-3 w-3" />
            {product.category}
          </Badge>
          <div className="flex items-center space-x-1">
            <div 
              className="w-12 h-2 bg-muted rounded-full progress-bar" 
              style={{"--progress": `${progressPercentage}%`} as React.CSSProperties}
            ></div>
            <span className="text-sm font-semibold text-primary" data-testid={`text-score-${product.id}`}>
              {sustainabilityScore.toFixed(1)}
            </span>
          </div>
        </div>
        
        <h3 className="text-lg font-semibold text-foreground mb-2" data-testid={`text-name-${product.id}`}>
          {product.name}
        </h3>
        
        <p className="text-muted-foreground text-sm mb-4" data-testid={`text-description-${product.id}`}>
          {product.description}
        </p>
        
        <div className="grid grid-cols-3 gap-2 text-xs mb-4">
          <div className="text-center">
            <div className={`font-semibold ${getCarbonFootprintColor(product.carbonFootprint)}`} data-testid={`text-carbon-${product.id}`}>
              {product.carbonFootprint}
            </div>
            <div className="text-muted-foreground">Carbon</div>
          </div>
          <div className="text-center">
            <div className="font-semibold text-chart-2" data-testid={`text-recyclability-${product.id}`}>
              {product.recyclability}%
            </div>
            <div className="text-muted-foreground">Recyclable</div>
          </div>
          <div className="text-center">
            <div className="font-semibold text-chart-3" data-testid={`text-durability-${product.id}`}>
              {product.durability}
            </div>
            <div className="text-muted-foreground">Durability</div>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-xl font-bold text-foreground" data-testid={`text-price-${product.id}`}>
            ${product.price}
          </span>
          <Button 
            onClick={() => onViewDetails?.(product)}
            data-testid={`button-view-details-${product.id}`}
          >
            View Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
