import Navigation from "@/components/navigation";
import DashboardMetrics from "@/components/dashboard-metrics";
import ImpactCalculator from "@/components/impact-calculator";
import AIRecommendation from "@/components/ai-recommendation";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "lucide-react";

export default function Dashboard() {
  const { data: dashboardData, isLoading } = useQuery<any>({
    queryKey: ["/api/dashboard"],
    staleTime: 300000, // 5 minutes
  });

  const { data: impactHistory = [] } = useQuery<any[]>({
    queryKey: ["/api/impact/history"],
    staleTime: 300000,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="animate-pulse space-y-8">
            <div className="h-8 bg-muted rounded w-64"></div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-48 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4">Environmental Impact Dashboard</h1>
          <p className="text-xl text-muted-foreground">
            Track your environmental footprint and see how your choices make a difference
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            {dashboardData && <DashboardMetrics metrics={dashboardData} />}
          </div>
          
          <div className="space-y-8">
            <ImpactCalculator />
            
            {dashboardData?.insights && (
              <AIRecommendation 
                insight={dashboardData.insights}
                onGetRecommendations={() => {/* Navigate to recommendations */}}
              />
            )}
          </div>
        </div>

        {/* Impact History */}
        {impactHistory.length > 0 && (
          <Card data-testid="card-impact-history">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Recent Impact Calculations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {impactHistory.slice(0, 5).map((calculation: any) => (
                  <div key={calculation.id} className="flex items-center justify-between p-4 border border-border rounded-lg" data-testid={`calculation-${calculation.id}`}>
                    <div>
                      <h4 className="font-medium text-foreground" data-testid={`text-calculation-product-${calculation.id}`}>
                        {calculation.productName}
                      </h4>
                      <p className="text-sm text-muted-foreground">{calculation.category}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(calculation.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline" data-testid={`badge-calculation-score-${calculation.id}`}>
                        {parseFloat(calculation.sustainabilityScore).toFixed(1)}/10
                      </Badge>
                      <div className="text-xs text-muted-foreground mt-1">
                        {parseFloat(calculation.carbonFootprint).toFixed(1)} kg CO₂
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
