import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import ImpactCalculator from "@/components/impact-calculator";
import DashboardMetrics from "@/components/dashboard-metrics";
import ProductCard from "@/components/product-card";
import AIRecommendation from "@/components/ai-recommendation";
import { Button } from "@/components/ui/button";
import { Calculator, Play } from "lucide-react";
import { Link } from "wouter";
import { Product } from "@shared/schema";

export default function Home() {
  const [selectedProducts] = useState<Product[]>([]);

  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    staleTime: 300000, // 5 minutes
  });

  const { data: dashboardData } = useQuery<any>({
    queryKey: ["/api/dashboard"],
    staleTime: 300000,
  });

  const featuredProducts = products.slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative pt-16 pb-32 overflow-hidden">
        <div className="absolute inset-0 gradient-eco opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-5xl lg:text-6xl font-bold text-foreground leading-tight">
                  Discover
                  <span className="text-primary block">Sustainable</span>
                  Products with AI
                </h1>
                <p className="text-xl text-muted-foreground leading-relaxed">
                  Get personalized eco-friendly product recommendations and track your environmental impact with our AI-powered sustainability platform.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/dashboard">
                  <Button size="lg" className="flex items-center space-x-2" data-testid="button-calculate-impact">
                    <Calculator className="h-5 w-5" />
                    <span>Calculate Impact</span>
                  </Button>
                </Link>
                <Button variant="outline" size="lg" className="flex items-center space-x-2" data-testid="button-watch-demo">
                  <Play className="h-5 w-5" />
                  <span>Watch Demo</span>
                </Button>
              </div>
              
              <div className="flex items-center space-x-8 pt-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary" data-testid="text-products-analyzed">50,000+</div>
                  <div className="text-sm text-muted-foreground">Products Analyzed</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary" data-testid="text-carbon-saved">2.5M kg</div>
                  <div className="text-sm text-muted-foreground">CO₂ Saved</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary" data-testid="text-users">25,000+</div>
                  <div className="text-sm text-muted-foreground">Users</div>
                </div>
              </div>
            </div>
            
            <div className="lg:pl-8">
              <ImpactCalculator />
            </div>
          </div>
        </div>
      </section>

      {/* Environmental Dashboard */}
      {dashboardData && (
        <section className="py-20 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-foreground mb-4">Environmental Impact Dashboard</h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Track your environmental footprint and see how your choices make a difference
              </p>
            </div>
            <DashboardMetrics metrics={dashboardData} />
          </div>
        </section>
      )}

      {/* Featured Products */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Featured Sustainable Products</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Discover eco-friendly alternatives with excellent sustainability ratings
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {featuredProducts.map((product: Product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="text-center">
            <Link href="/products">
              <Button size="lg" data-testid="button-view-all-products">
                View All Products
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* AI Recommendation */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AIRecommendation 
            insight="Based on current market trends and sustainability data, focusing on renewable energy products and biodegradable materials could reduce your carbon footprint by an additional 15% this year."
            onGetRecommendations={() => {/* Navigate to recommendations */}}
          />
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <span className="text-primary-foreground text-sm">🌱</span>
                </div>
                <span className="text-xl font-bold">EcoWise</span>
              </div>
              <p className="text-background/70">
                AI-powered sustainability platform helping you make environmentally conscious purchasing decisions.
              </p>
            </div>
            
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Features</h3>
              <ul className="space-y-2">
                <li><Link href="/dashboard" className="text-background/70 hover:text-background transition-colors">Impact Calculator</Link></li>
                <li><Link href="/products" className="text-background/70 hover:text-background transition-colors">Product Database</Link></li>
                <li><Link href="/products" className="text-background/70 hover:text-background transition-colors">AI Recommendations</Link></li>
                <li><Link href="/compare" className="text-background/70 hover:text-background transition-colors">Comparison Tool</Link></li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Resources</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-background/70 hover:text-background transition-colors">Sustainability Guide</a></li>
                <li><a href="#" className="text-background/70 hover:text-background transition-colors">API Documentation</a></li>
                <li><a href="#" className="text-background/70 hover:text-background transition-colors">Case Studies</a></li>
                <li><a href="#" className="text-background/70 hover:text-background transition-colors">Blog</a></li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Company</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-background/70 hover:text-background transition-colors">About Us</a></li>
                <li><a href="#" className="text-background/70 hover:text-background transition-colors">Contact</a></li>
                <li><a href="#" className="text-background/70 hover:text-background transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="text-background/70 hover:text-background transition-colors">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 border-t border-background/20 flex flex-col md:flex-row justify-between items-center">
            <p className="text-background/70 text-sm">
              © 2024 EcoWise. All rights reserved.
            </p>
            <p className="text-background/70 text-sm mt-4 md:mt-0">
              Powered by AI • Made with 🌱 for the planet
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
