# Overview

EcoWise is an AI-powered sustainability platform that helps users discover eco-friendly products, track their environmental impact, and make informed purchasing decisions. The application provides personalized product recommendations, environmental impact calculations, and comprehensive sustainability metrics through an intuitive web interface.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React SPA**: Built with React 18 using TypeScript and Vite for fast development and hot module replacement
- **Component System**: Utilizes shadcn/ui components with Radix UI primitives for accessible, customizable UI elements
- **Styling**: TailwindCSS with custom CSS variables for theming, supporting both light and dark modes with an eco-friendly color palette
- **State Management**: TanStack Query for server state management, caching, and API synchronization
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

## Backend Architecture
- **Express.js Server**: RESTful API server with middleware for JSON parsing, logging, and error handling
- **Database Layer**: Drizzle ORM with PostgreSQL schema definitions in shared directory for type-safe database operations
- **Storage Interface**: Abstracted storage layer with in-memory implementation for development and PostgreSQL adapter for production
- **API Endpoints**: Modular route structure with dedicated endpoints for products, impact calculations, recommendations, and dashboard metrics

## Data Models
- **Users**: Authentication and profile management
- **Products**: Sustainability-focused product catalog with environmental metrics
- **Impact Calculations**: Historical environmental impact assessments
- **User Preferences**: Personalized settings for recommendations and filtering

## AI Integration
- **OpenAI API**: GPT-5 integration for environmental impact analysis and personalized recommendations
- **Services**: Dedicated AI service layer for product impact calculation, sustainability insights, and alternative product suggestions

## Development Tooling
- **TypeScript**: Full-stack type safety with shared types and schemas
- **Build System**: Vite for frontend bundling, esbuild for server compilation
- **Database Migrations**: Drizzle Kit for schema management and database migrations
- **Development Server**: Integrated development environment with hot reloading and error overlays

# External Dependencies

## Core Infrastructure
- **PostgreSQL Database**: Primary data storage using Neon serverless database
- **OpenAI API**: GPT-5 model for AI-powered sustainability analysis and recommendations

## UI Framework
- **Radix UI**: Accessible component primitives for dialogs, dropdowns, navigation, and form controls
- **Lucide Icons**: Comprehensive icon library for UI elements
- **Recharts**: Chart library for dashboard visualizations and metrics display

## Development Tools
- **Replit Integration**: Development environment plugins for runtime error handling and debugging
- **PostCSS**: CSS processing with TailwindCSS and Autoprefixer
- **Embla Carousel**: Touch-friendly carousel component for product showcases

## Authentication & Session Management
- **connect-pg-simple**: PostgreSQL session store for Express sessions
- **Date utilities**: date-fns for date formatting and manipulation

## Validation & Type Safety
- **Zod**: Runtime type validation and schema generation
- **drizzle-zod**: Integration between Drizzle ORM and Zod for type-safe database schemas