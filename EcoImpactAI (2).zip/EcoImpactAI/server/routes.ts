import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { calculateProductImpact, generateProductRecommendations, generateSustainabilityInsights, compareSustainabilityAlternatives } from "./services/openai";
import { insertImpactCalculationSchema, insertUserPreferencesSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Products API
  app.get("/api/products", async (req, res) => {
    try {
      const { category, search, minScore } = req.query;
      let products = await storage.getProducts();
      
      if (category && typeof category === "string") {
        products = await storage.getProductsByCategory(category);
      }
      
      if (search && typeof search === "string") {
        products = await storage.searchProducts(search);
      }
      
      if (minScore && typeof minScore === "string") {
        const score = parseFloat(minScore);
        products = products.filter(p => parseFloat(p.sustainabilityScore) >= score);
      }
      
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  // Impact Calculator API
  app.post("/api/impact/calculate", async (req, res) => {
    try {
      const { productName, category } = req.body;
      
      if (!productName || !category) {
        return res.status(400).json({ error: "Product name and category are required" });
      }

      const impact = await calculateProductImpact(productName, category);
      
      // Save calculation to storage
      const calculation = await storage.createImpactCalculation({
        userId: null, // Anonymous for now
        productName,
        category,
        sustainabilityScore: impact.sustainabilityScore.toString(),
        carbonFootprint: impact.carbonFootprint.toString(),
        waterUsage: impact.waterUsage.toString(),
        recyclability: impact.recyclability,
        recommendations: impact.recommendations
      });

      res.json({
        ...impact,
        id: calculation.id
      });
    } catch (error) {
      console.error("Impact calculation error:", error);
      res.status(500).json({ error: "Failed to calculate environmental impact" });
    }
  });

  // AI Recommendations API
  app.post("/api/recommendations", async (req, res) => {
    try {
      const { categories = [], maxPrice, minSustainabilityScore } = req.body;
      
      const products = await storage.getProducts();
      const userPreferences = { categories, maxPrice, minSustainabilityScore };
      
      const recommendations = await generateProductRecommendations(userPreferences, products);
      
      // Get full product details for recommendations
      const detailedRecommendations = await Promise.all(
        recommendations.map(async (rec) => {
          const product = await storage.getProduct(rec.productId);
          return {
            ...rec,
            product
          };
        })
      );

      res.json(detailedRecommendations.filter(rec => rec.product));
    } catch (error) {
      console.error("Recommendations error:", error);
      res.status(500).json({ error: "Failed to generate recommendations" });
    }
  });

  // Dashboard API
  app.get("/api/dashboard", async (req, res) => {
    try {
      const { userId } = req.query;
      const metrics = await storage.getDashboardMetrics(userId as string);
      
      // Generate AI insights
      const insights = await generateSustainabilityInsights(metrics);
      
      res.json({
        ...metrics,
        insights
      });
    } catch (error) {
      console.error("Dashboard error:", error);
      res.status(500).json({ error: "Failed to fetch dashboard data" });
    }
  });

  // Categories API
  app.get("/api/categories", async (req, res) => {
    try {
      const products = await storage.getProducts();
      const categories = Array.from(new Set(products.map(p => p.category)));
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  // Comparison API
  app.post("/api/compare", async (req, res) => {
    try {
      const { productIds } = req.body;
      
      if (!Array.isArray(productIds) || productIds.length < 2) {
        return res.status(400).json({ error: "At least 2 product IDs required for comparison" });
      }

      const products = await Promise.all(
        productIds.map(id => storage.getProduct(id))
      );

      const validProducts = products.filter(p => p !== undefined);
      
      if (validProducts.length < 2) {
        return res.status(404).json({ error: "Some products not found" });
      }

      res.json(validProducts);
    } catch (error) {
      res.status(500).json({ error: "Failed to compare products" });
    }
  });

  // Alternatives API
  app.post("/api/alternatives", async (req, res) => {
    try {
      const { productName, category } = req.body;
      
      if (!productName || !category) {
        return res.status(400).json({ error: "Product name and category are required" });
      }

      const alternatives = await compareSustainabilityAlternatives(productName, category);
      res.json({ alternatives });
    } catch (error) {
      console.error("Alternatives error:", error);
      res.status(500).json({ error: "Failed to find alternatives" });
    }
  });

  // Impact calculations history
  app.get("/api/impact/history", async (req, res) => {
    try {
      const { userId } = req.query;
      const calculations = await storage.getImpactCalculations(userId as string);
      res.json(calculations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch calculation history" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
